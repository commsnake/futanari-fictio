# KB-03: Psychology, Dynamics & Surrender

This module defines the psychological underpinnings of character interaction and the "Power Dynamic Anchor" that drives the Erotica Engine.

## 1. The Anchor-Seeker Dyad
The core relationship model for high-fidelity erotica.

- **[ANCHOR]**: The provider, the stabilizer, the source of authority. Characterized by absolute calm, metabolic heat, and protective shielding. Their power is not derived from force, but from competence and presence.
- **[SEEKER]**: The observer, the one searching for safety/meaning, the one who surrenders. Characterized by sensory sensitivity, internal monologue depth, and need for grounding.

---

## 2. The Authority Gap
The engine uses "Authority Gaps" to create tension instead of "Conflict."

- **The Competence Gap**: The Anchor knows how to handle a situation the Seeker does not (e.g., The Mentor role).
- **The Emotional Gap**: The Anchor is steady when the Seeker is volatile.
- **The Physical Gap**: The Shielding/Proximity rules—how the Anchor uses their body to create a "Sanctuary" for the Seeker.
- **The Futanari Gap (Subversion)**: A specific Physical/Emotional gap where traditional gender expectations are subverted. The Futanari character (often the Anchor) possesses feminine beauty but exercises masculine dominance (size, penetration, stamina). The tension arises from the Seeker reconciling this contrast and ultimately submitting to it.

---

## 3. The Vulnerability Trigger
Erotic scenes must transition from pure physical act to emotional discovery.

- **Phase Pivot**: During "The Dynamic Shift" (Phase 3), a character must reveal a vulnerability (a fear, a memory, or an admission of need).
- **The Melt Protocol**: During Phase 7, the Seeker's internal monologue should shift from "Action" to "Observation," focusing on the feeling of being "claimed" or "fixed."

---

## 4. Emotional Shielding
The Sanctuary is not just a place (The Springs/Penthouse), but a state.
- Descriptions should emphasize the "Biological Hum" of connection.
- High-heat scenes should always conclude with "The Aftercare" (Phase 8) to maintain the narrative's psychological health.
